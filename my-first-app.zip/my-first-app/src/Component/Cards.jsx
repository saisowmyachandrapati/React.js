import React from 'react'

function Cards() {
    return (
        <div>
            <div className="row row-cols-1 row-cols-md-5 g-4">
            <button type="button" className="btn btn-light"> <div className="col">
                    <div className="card">
                        <img src="https://www.kuvingsusa.com/cdn/shop/articles/077931d29bfc10af2a246d30f51907d7.jpg?v=1656108581" style={{ width: '100%', height: '30vh' }} className="card-img-top" alt="..." />
                        <div className="card-body">
                            <h5 className="card-title">Vegtables</h5>
                        </div>
                    </div>
                </div></button>
                <button type="button" className="btn btn-light"><div className="col">
                    <div className="card">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvZydfrrV4_n8Cq1YPB5ESh2tBxHcAcbdxKA&s" style={{ width: '100%', height: '30vh' }} className="card-img-top" alt="..." />
                        <div className="card-body">
                             <h5 className="card-title">Honey</h5>
                        </div>
                    </div>
                </div></button>
                <button type="button" className="btn btn-light"><div className="col">
                    <div className="card">
                        <img src="https://imgk.timesnownews.com/story/1549350468-dals.PNG?tr=w-400,h-300,fo-auto" style={{ width: '100%', height: '30vh' }} className="card-img-top" alt="..." />
                        <div className="card-body">
                            <h5 className="card-title">Dals</h5>
                        </div>
                    </div>
                </div></button>
                <button type="button" className="btn btn-light"><div className="col">
                    <div className="card">
                        <img src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/202312/6-fruits-to-eat-on-empty-stomach-053937965-1x1.jpg?VersionId=xIXuT3WPQa4V8dHjQllmefHlDH1mfNDw" style={{ width: '100%', height: '30vh' }} className="card-img-top" alt="..." />
                        <div className="card-body">
                            <h5 className="card-title">Fruits</h5>
                        </div>
                    </div>
                </div></button>
                <button type="button" className="btn btn-light"><div className="col">
                    <div className="card">
                        <img src="https://static.vecteezy.com/system/resources/previews/025/002/249/large_2x/spice-dry-mix-seasoning-food-herb-background-indian-ingredient-cooking-powder-generative-ai-photo.jpg" style={{ width: '100%', height: '30vh' }} className="card-img-top" alt="..." />
                        <div className="card-body">
                            <h5 className="card-title">Food Seasoning</h5>
                        </div>
                    </div>
                </div></button>
            </div>
        </div>
    )
}

export default Cards;

