
import './App.css';
import Carousel from './Component/Carousel';
import Navbar from './Component/Navbar';
import Cards from './Component/Cards';

function App() {
  return (
    <div className="App">
      <Navbar />
      <div className="container my-3">
      <Carousel/>
      </div>
      <div className="container my-3">
      <Cards/>
      </div>
    </div>
  );
}

export default App;
